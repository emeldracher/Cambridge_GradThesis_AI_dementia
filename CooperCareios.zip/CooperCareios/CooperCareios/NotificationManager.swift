import Foundation
import UserNotifications

final class NotificationManager {
    static let shared = NotificationManager()

    private init() {}

    func requestPermission() async {
        do {
            let granted = try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])

            print("Notification permission granted:", granted)

            let settings = await UNUserNotificationCenter.current().notificationSettings()
            print("Authorization status:", settings.authorizationStatus.rawValue)
        } catch {
            print("Permission error:", error)
        }
    }

    func scheduleNotification(
        title: String,
        body: String,
        year: Int?,
        month: Int?,
        day: Int?,
        hour: Int?,
        minute: Int?,
        second: Int?,
        isRecurring: Bool,
        recurrence: String?,
        weekday: Int?
    ) async {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default

        var components = DateComponents()
        components.hour = hour
        components.minute = minute
        components.second = second ?? 0

        if isRecurring {
            if recurrence == "weekly" {
                components.weekday = weekday
            }
        } else {
            components.year = year
            components.month = month
            components.day = day
        }

        let calendar = Calendar.current

        if !isRecurring {
            if let date = calendar.date(from: components),
               date < Date() {
                print("Time was in the past. Adjusting by 1 minute.")
                if let adjustedDate = calendar.date(byAdding: .minute, value: 1, to: Date()) {
                    components = calendar.dateComponents(
                        [.year, .month, .day, .hour, .minute, .second],
                        from: adjustedDate
                    )
                }
            }
        }

        let trigger = UNCalendarNotificationTrigger(
            dateMatching: components,
            repeats: isRecurring
        )

        let identifier = UUID().uuidString

        let request = UNNotificationRequest(
            identifier: identifier,
            content: content,
            trigger: trigger
        )

        do {
            try await UNUserNotificationCenter.current().add(request)
            print("Scheduled notification:", identifier)
            await printPending()
        } catch {
            print("Scheduling error:", error)
        }
    }

    func printPending() async {
        let pending = await UNUserNotificationCenter.current().pendingNotificationRequests()
        print("Pending notification count:", pending.count)
        for item in pending {
            print("Pending id:", item.identifier)
            print("Pending title:", item.content.title)
            print("Pending body:", item.content.body)
        }
    }
}
