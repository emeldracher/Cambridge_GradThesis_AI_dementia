import SwiftUI

struct AppTabView: View {
    var body: some View {
        TabView {
            NavigationStack {
                ContentView()
            }
            .tabItem {
                Label("Talk", systemImage: "message")
            }

            NavigationStack {
                RemindersView()
            }
            .tabItem {
                Label("Reminders", systemImage: "bell")
            }

            NavigationStack {
                GamesView()
            }
            .tabItem {
                Label("Games", systemImage: "gamecontroller")
            }

            NavigationStack {
                MemoryView()
            }
            .tabItem {
                Label("Memory", systemImage: "brain")
                
            }
        }
    }
}

#Preview {
    AppTabView()
        .environmentObject(ReminderStore())
        .environmentObject(ConversationMemoryStore())
}
