import SwiftUI

struct ChatMessage: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool
}

struct ContentView: View {
    @EnvironmentObject var reminderStore: ReminderStore
    @EnvironmentObject var memoryStore: ConversationMemoryStore

    @StateObject private var speechManager = SpeechManager()
    @StateObject private var speechOutput = SpeechOutputManager.shared

    @State private var messages: [ChatMessage] = [
        ChatMessage(
            text: "Hi. I’m Cooper. I’m here with you. You can talk to me, type to me, or ask me to remind you about something.",
            isUser: false
        )
    ]

    @State private var inputText = ""
    @State private var isLoading = false
    @State private var speakResponses = true

    var body: some View {
        VStack(spacing: 0) {
            dogHeader

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 14) {
                        ForEach(messages) { message in
                            if message.isUser {
                                userBubble(message.text)
                            } else {
                                dogBubble(message.text)
                            }
                        }

                        if isLoading {
                            dogBubble("Thinking...")
                        }
                    }
                    .padding()
                }
                .onChange(of: messages.count) {
                    if let lastID = messages.last?.id {
                        proxy.scrollTo(lastID, anchor: .bottom)
                    }
                }
            }

            memoryChips

            if !speechManager.authorizationMessage.isEmpty {
                Text(speechManager.authorizationMessage)
                    .font(.footnote)
                    .foregroundColor(.red)
                    .padding(.horizontal)
                    .padding(.top, 8)
            }

            Divider()

            inputBar
        }
        .navigationTitle("Cooper")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await speechManager.requestPermissions()
        }
        .onReceive(speechManager.$transcript) { newTranscript in
            if !newTranscript.isEmpty {
                inputText = newTranscript
            }
        }
    }

    var dogHeader: some View {
        VStack(spacing: 8) {
            Text("🐶")
                .font(.system(size: 72))

            Text("Cooper")
                .font(.title2)
                .bold()

            Text("Your Favorite AI Canine Companion")
                .font(.subheadline)
                .foregroundColor(.secondary)

            Toggle("Speak aloud", isOn: $speakResponses)
                .toggleStyle(.switch)
                .font(.footnote)
                .padding(.horizontal, 80)
        }
        .padding(.top, 12)
        .padding(.bottom, 10)
        .background(Color.orange.opacity(0.08))
    }

    var memoryChips: some View {
        Group {
            if !memoryStore.profileFacts.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(memoryStore.profileFacts.prefix(6)) { fact in
                            Text("\(fact.key): \(fact.value)")
                                .font(.caption)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(fact.source == "caregiver" ? Color.red.opacity(0.15) : Color.orange.opacity(0.15))
                                .cornerRadius(12)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.bottom, 6)
            }
        }
    }

    var inputBar: some View {
        HStack(spacing: 8) {
            TextField("Talk to Cooper...", text: $inputText, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .lineLimit(1...4)

            Button {
                if speechManager.isListening {
                    speechManager.stopListening()
                } else {
                    speechManager.startListening()
                }
            } label: {
                Image(systemName: speechManager.isListening ? "mic.fill" : "mic")
                    .font(.title2)
                    .padding(10)
                    .background(speechManager.isListening ? Color.red.opacity(0.2) : Color.gray.opacity(0.15))
                    .clipShape(Circle())
            }

            Button {
                SpeechOutputManager.shared.stop()
            } label: {
                Image(systemName: speechOutput.isSpeaking ? "speaker.wave.2.fill" : "speaker.slash")
                    .font(.title2)
                    .padding(10)
                    .background(Color.gray.opacity(0.15))
                    .clipShape(Circle())
            }

            Button("Send") {
                Task {
                    await sendMessage()
                }
            }
            .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isLoading)
        }
        .padding()
    }

    func dogBubble(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text("🐶")
                .font(.title)

            Text(text)
                .font(.body)
                .padding(14)
                .background(Color.orange.opacity(0.16))
                .cornerRadius(18)
                .frame(maxWidth: 310, alignment: .leading)

            Spacer()
        }
    }

    func userBubble(_ text: String) -> some View {
        HStack {
            Spacer()

            Text(text)
                .font(.body)
                .padding(14)
                .background(Color.blue.opacity(0.15))
                .cornerRadius(18)
                .frame(maxWidth: 310, alignment: .trailing)
        }
    }

    func sendMessage() async {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        SpeechOutputManager.shared.stop()

        messages.append(ChatMessage(text: trimmed, isUser: true))
        memoryStore.addMessage(role: "user", content: trimmed)

        inputText = ""
        isLoading = true

        do {
            let repeatCount = memoryStore.inferredRepeatCount(for: trimmed)

            let response = try await APIService.shared.sendMessage(
                trimmed,
                recentMessages: memoryStore.recentMessages,
                profileFacts: memoryStore.profileFacts,
                summary: memoryStore.summary,
                repeatCountForMessage: repeatCount
            )

            let dogResponse = response.assistant_message

            messages.append(ChatMessage(text: dogResponse, isUser: false))
            memoryStore.addMessage(role: "assistant", content: dogResponse)

            memoryStore.applyMemoryUpdates(response.memory_updates ?? [])
            memoryStore.updateSummary(response.updated_summary)

            if let topic = response.detected_topic, response.repeat_likely == true {
                memoryStore.incrementRepeatCount(for: topic)
            }

            var spokenText = dogResponse

            if response.should_schedule_reminder {
                let title = response.title ?? "Reminder"
                let body = response.notes ?? title

                await NotificationManager.shared.scheduleNotification(
                    title: title,
                    body: body,
                    year: response.year,
                    month: response.month,
                    day: response.day,
                    hour: response.hour,
                    minute: response.minute,
                    second: response.second,
                    isRecurring: response.is_recurring ?? false,
                    recurrence: response.recurrence,
                    weekday: response.weekday
                )

                let confirmationText: String
                if response.is_recurring ?? false {
                    if response.recurrence == "daily" {
                        confirmationText = "Okay. I will remind you every day: \(title)."
                    } else if response.recurrence == "weekly" {
                        confirmationText = "Okay. I will remind you every week: \(title)."
                    } else {
                        confirmationText = "Okay. I will set a repeating reminder: \(title)."
                    }
                } else {
                    confirmationText = "Okay. I will remind you: \(title)."
                }

                messages.append(ChatMessage(text: confirmationText, isUser: false))
                memoryStore.addMessage(role: "assistant", content: confirmationText)

                spokenText += " " + confirmationText

                let reminderItem = ReminderItem(
                    title: title,
                    notes: response.notes,
                    isRecurring: response.is_recurring ?? false,
                    recurrence: response.recurrence,
                    weekday: response.weekday,
                    scheduledDate: makeDate(from: response),
                    hour: response.hour,
                    minute: response.minute,
                    second: response.second
                )

                reminderStore.addReminder(reminderItem)
            }

            if speakResponses {
                await SpeechOutputManager.shared.speakFromBackend(spokenText)
            }

        } catch {
            let errorMessage = "I’m sorry. I had trouble connecting just now."

            messages.append(ChatMessage(text: errorMessage, isUser: false))

            if speakResponses {
                await SpeechOutputManager.shared.speakFromBackend(errorMessage)
            }

            print("App error:", error)
        }

        isLoading = false
    }

    func makeDate(from response: ChatResponse) -> Date? {
        guard
            let year = response.year,
            let month = response.month,
            let day = response.day,
            let hour = response.hour,
            let minute = response.minute
        else {
            return nil
        }

        var components = DateComponents()
        components.year = year
        components.month = month
        components.day = day
        components.hour = hour
        components.minute = minute
        components.second = response.second ?? 0
        components.timeZone = TimeZone.current

        return Calendar.current.date(from: components)
    }
}

#Preview {
    NavigationStack {
        ContentView()
            .environmentObject(ReminderStore())
            .environmentObject(ConversationMemoryStore())
    }
}
