//
//  CategoryChallengeView.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import SwiftUI

struct CategoryChallengeView: View {
    private let prompts = [
        "Name an animal",
        "Name a fruit",
        "Name a color",
        "Name a flower",
        "Name a place",
        "Name something to eat"
    ]

    @State private var currentIndex = 0
    @State private var answer = ""
    @State private var feedback = ""

    var body: some View {
        VStack(spacing: 24) {
            Text("Category Challenge")
                .font(.title2)

            Text(prompts[currentIndex])
                .font(.title3)
                .multilineTextAlignment(.center)
                .padding()

            TextField("Type your answer", text: $answer)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button("Submit") {
                submit()
            }
            .buttonStyle(.borderedProminent)

            if !feedback.isEmpty {
                Text(feedback)
                    .font(.headline)
            }

            Button("Next Prompt") {
                nextPrompt()
            }
            .buttonStyle(.bordered)

            Spacer()
        }
        .padding()
        .navigationTitle("Category Challenge")
    }

    func submit() {
        if answer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            feedback = "Please try one answer."
        } else {
            feedback = "Nice answer."
        }
    }

    func nextPrompt() {
        currentIndex = (currentIndex + 1) % prompts.count
        answer = ""
        feedback = ""
    }
}

#Preview {
    NavigationStack {
        CategoryChallengeView()
    }
}
