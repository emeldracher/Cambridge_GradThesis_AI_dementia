import Foundation

struct MemoryUpdate: Decodable, Equatable {
    let type: String
    let key: String
    let value: String
    let category: String
    let notes: String?
}

struct ChatResponse: Decodable {
    let assistant_message: String
    let should_schedule_reminder: Bool
    let title: String?
    let year: Int?
    let month: Int?
    let day: Int?
    let hour: Int?
    let minute: Int?
    let second: Int?
    let is_recurring: Bool?
    let recurrence: String?
    let weekday: Int?
    let notes: String?

    let memory_updates: [MemoryUpdate]?
    let detected_topic: String?
    let repeat_likely: Bool?
    let updated_summary: String?
}
