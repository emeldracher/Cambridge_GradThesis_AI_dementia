//
//  MemoryView.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/22/26.
//

import SwiftUI

struct MemoryView: View {
    @EnvironmentObject var memoryStore: ConversationMemoryStore
    @State private var showingAddSheet = false

    var body: some View {
        List {
            if !memoryStore.summary.isEmpty {
                Section("Session Summary") {
                    Text(memoryStore.summary)
                        .font(.body)
                }
            }

            Section("Caregiver Notes") {
                let caregiverFacts = memoryStore.profileFacts.filter { $0.source == "caregiver" }

                if caregiverFacts.isEmpty {
                    Text("No caregiver notes yet.")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(caregiverFacts) { fact in
                        NavigationLink {
                            MemoryFactEditorView(fact: fact)
                        } label: {
                            MemoryFactRow(fact: fact)
                        }
                    }
                    .onDelete { offsets in
                        deleteFacts(in: caregiverFacts, offsets: offsets)
                    }
                }

                Button("Add Caregiver Note") {
                    showingAddSheet = true
                }
            }

            Section("Known Facts") {
                let assistantFacts = memoryStore.profileFacts.filter { $0.source != "caregiver" }

                if assistantFacts.isEmpty {
                    Text("No saved facts yet.")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(assistantFacts) { fact in
                        NavigationLink {
                            MemoryFactEditorView(fact: fact)
                        } label: {
                            MemoryFactRow(fact: fact)
                        }
                    }
                    .onDelete { offsets in
                        deleteFacts(in: assistantFacts, offsets: offsets)
                    }
                }
            }

            Section("Controls") {
                Button("Clear Conversation Context") {
                    memoryStore.clearConversationOnly()
                }
                .foregroundColor(.orange)

                Button("Clear All Memory") {
                    memoryStore.clearAll()
                }
                .foregroundColor(.red)
            }
        }
        .navigationTitle("Memory")
        .sheet(isPresented: $showingAddSheet) {
            NavigationStack {
                MemoryFactEditorView(
                    fact: MemoryFact(
                        key: "",
                        value: "",
                        category: "caregiver_note",
                        source: "caregiver",
                        notes: ""
                    ),
                    isNew: true
                )
            }
            .environmentObject(memoryStore)
        }
    }

    private func deleteFacts(in filteredFacts: [MemoryFact], offsets: IndexSet) {
        let idsToDelete = offsets.map { filteredFacts[$0].id }
        let allOffsets = IndexSet(
            memoryStore.profileFacts.enumerated().compactMap { index, fact in
                idsToDelete.contains(fact.id) ? index : nil
            }
        )
        memoryStore.deleteFact(at: allOffsets)
    }
}

struct MemoryFactRow: View {
    let fact: MemoryFact

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(fact.key)
                    .font(.headline)
                Spacer()
                Text(fact.source.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(fact.source == "caregiver" ? Color.red.opacity(0.15) : Color.blue.opacity(0.15))
                    .cornerRadius(8)
            }

            Text(fact.value)
                .font(.body)

            Text(fact.category)
                .font(.caption)
                .foregroundColor(.secondary)

            if let notes = fact.notes, !notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text(notes)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

struct MemoryFactEditorView: View {
    @EnvironmentObject var memoryStore: ConversationMemoryStore
    @Environment(\.dismiss) private var dismiss

    let fact: MemoryFact
    var isNew: Bool = false

    @State private var key: String
    @State private var value: String
    @State private var category: String
    @State private var source: String
    @State private var notes: String

    init(fact: MemoryFact, isNew: Bool = false) {
        self.fact = fact
        self.isNew = isNew
        _key = State(initialValue: fact.key)
        _value = State(initialValue: fact.value)
        _category = State(initialValue: fact.category)
        _source = State(initialValue: fact.source)
        _notes = State(initialValue: fact.notes ?? "")
    }

    var body: some View {
        Form {
            Section("Main") {
                TextField("Name or key", text: $key)
                TextField("Value", text: $value)
                TextField("Category", text: $category)
            }

            Section("Source") {
                Picker("Source", selection: $source) {
                    Text("Caregiver").tag("caregiver")
                    Text("Assistant").tag("assistant")
                }
                .pickerStyle(.segmented)
            }

            Section("Guidance") {
                TextEditor(text: $notes)
                    .frame(minHeight: 120)
            }

            Section("Examples") {
                Text("Joe → husband")
                Text("Joe_status → died")
                Text("Residence → Rosewood Memory Care")
                Text("Timeshift → sometimes believes she is 20")
                Text("Guidance note → do not suggest calling Joe")
            }
            .font(.caption)
            .foregroundColor(.secondary)
        }
        .navigationTitle(isNew ? "New Memory" : "Edit Memory")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") {
                    dismiss()
                }
            }

            ToolbarItem(placement: .confirmationAction) {
                Button("Save") {
                    save()
                }
                .disabled(
                    key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    category.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                )
            }
        }
    }

    private func save() {
        memoryStore.addOrUpdateFact(
            key: key,
            value: value,
            category: category,
            source: source,
            notes: notes
        )
        dismiss()
    }
}

#Preview {
    NavigationStack {
        MemoryView()
            .environmentObject(ConversationMemoryStore())
    }
}
