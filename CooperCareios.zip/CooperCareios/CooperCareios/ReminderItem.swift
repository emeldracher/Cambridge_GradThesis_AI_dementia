//
//  ReminderItem.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import Foundation

struct ReminderItem: Identifiable, Codable, Equatable {
    let id: UUID
    let title: String
    let notes: String?
    let createdAt: Date
    let isRecurring: Bool
    let recurrence: String?
    let weekday: Int?
    let scheduledDate: Date?
    let hour: Int?
    let minute: Int?
    let second: Int?

    init(
        id: UUID = UUID(),
        title: String,
        notes: String? = nil,
        createdAt: Date = Date(),
        isRecurring: Bool,
        recurrence: String? = nil,
        weekday: Int? = nil,
        scheduledDate: Date? = nil,
        hour: Int? = nil,
        minute: Int? = nil,
        second: Int? = nil
    ) {
        self.id = id
        self.title = title
        self.notes = notes
        self.createdAt = createdAt
        self.isRecurring = isRecurring
        self.recurrence = recurrence
        self.weekday = weekday
        self.scheduledDate = scheduledDate
        self.hour = hour
        self.minute = minute
        self.second = second
    }
}
