//
//  ReminderStore.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import Foundation

@MainActor
final class ReminderStore: ObservableObject {
    @Published var reminders: [ReminderItem] = []

    private let saveKey = "coopercare_saved_reminders"

    init() {
        load()
    }

    func addReminder(_ reminder: ReminderItem) {
        reminders.insert(reminder, at: 0)
        save()
    }

    func deleteReminder(at offsets: IndexSet) {
        reminders.remove(atOffsets: offsets)
        save()
    }

    func clearAll() {
        reminders.removeAll()
        save()
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(reminders)
            UserDefaults.standard.set(data, forKey: saveKey)
        } catch {
            print("Failed to save reminders:", error)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: saveKey) else { return }

        do {
            reminders = try JSONDecoder().decode([ReminderItem].self, from: data)
        } catch {
            print("Failed to load reminders:", error)
        }
    }
}
