//
//  WordScrambleView.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import SwiftUI

struct WordScrambleView: View {
    private let wordPairs: [(scrambled: String, answer: String)] = [
        ("AELPP", "APPLE"),
        ("ROEFLW", "FLOWER"),
        ("TCA", "CAT"),
        ("RTAEW", "WATER"),
        ("OUHSE", "HOUSE")
    ]

    @State private var currentIndex = 0
    @State private var guess = ""
    @State private var feedback = ""

    var body: some View {
        VStack(spacing: 24) {
            Text("Unscramble the word")
                .font(.title2)

            Text(wordPairs[currentIndex].scrambled)
                .font(.system(size: 40, weight: .bold))
                .padding()

            TextField("Type your answer", text: $guess)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button("Check") {
                checkAnswer()
            }
            .buttonStyle(.borderedProminent)

            if !feedback.isEmpty {
                Text(feedback)
                    .font(.headline)
            }

            Button("Next Word") {
                nextWord()
            }
            .buttonStyle(.bordered)

            Spacer()
        }
        .padding()
        .navigationTitle("Word Scramble")
    }

    func checkAnswer() {
        if guess.trimmingCharacters(in: .whitespacesAndNewlines).uppercased() == wordPairs[currentIndex].answer {
            feedback = "Nice job!"
        } else {
            feedback = "Good try. Try again."
        }
    }

    func nextWord() {
        currentIndex = (currentIndex + 1) % wordPairs.count
        guess = ""
        feedback = ""
    }
}

#Preview {
    NavigationStack {
        WordScrambleView()
    }
}
