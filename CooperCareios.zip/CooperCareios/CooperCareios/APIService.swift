import Foundation

struct ChatRequestBody: Encodable {
    let message: String
    let recent_messages: [ConversationTurn]
    let profile_facts: [MemoryFact]
    let summary: String
    let repeat_count_for_message: Int
}

final class APIService {
    static let shared = APIService()

    private init() {}

    func sendMessage(
        _ message: String,
        recentMessages: [ConversationTurn],
        profileFacts: [MemoryFact],
        summary: String,
        repeatCountForMessage: Int
    ) async throws -> ChatResponse {
        guard let url = URL(string: "http://127.0.0.1:3000/chat") else {
            throw URLError(.badURL)
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = ChatRequestBody(
            message: message,
            recent_messages: recentMessages,
            profile_facts: profileFacts,
            summary: summary,
            repeat_count_for_message: repeatCountForMessage
        )

        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            let serverText = String(data: data, encoding: .utf8) ?? "Unknown server error"
            print("Server returned:", serverText)
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode(ChatResponse.self, from: data)
    }
}
