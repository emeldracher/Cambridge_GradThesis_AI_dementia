//
//  RemindersView.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import SwiftUI

struct RemindersView: View {
    @EnvironmentObject var reminderStore: ReminderStore

    var body: some View {
        List {
            if reminderStore.reminders.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("No reminders yet")
                        .font(.headline)
                    Text("Set a reminder in Talk and it will appear here.")
                        .foregroundColor(.secondary)
                }
                .padding(.vertical, 12)
            } else {
                ForEach(reminderStore.reminders) { reminder in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(reminder.title)
                            .font(.headline)

                        if let notes = reminder.notes, !notes.isEmpty {
                            Text(notes)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }

                        if reminder.isRecurring {
                            Text(recurringDescription(for: reminder))
                                .font(.footnote)
                                .foregroundColor(.blue)
                        } else if let scheduledDate = reminder.scheduledDate {
                            Text(scheduledDate.formatted(date: .abbreviated, time: .shortened))
                                .font(.footnote)
                                .foregroundColor(.blue)
                        }

                        Text("Added \(reminder.createdAt.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                .onDelete(perform: reminderStore.deleteReminder)
            }
        }
        .navigationTitle("Reminders")
        .toolbar {
            if !reminderStore.reminders.isEmpty {
                Button("Clear All") {
                    reminderStore.clearAll()
                }
            }
        }
    }

    func recurringDescription(for reminder: ReminderItem) -> String {
        if reminder.recurrence == "daily" {
            let timeText = formattedTime(hour: reminder.hour, minute: reminder.minute)
            return "Every day\(timeText.map { " at \($0)" } ?? "")"
        }

        if reminder.recurrence == "weekly" {
            let weekdayText = weekdayName(reminder.weekday)
            let timeText = formattedTime(hour: reminder.hour, minute: reminder.minute)
            if let weekdayText {
                if let timeText {
                    return "Every \(weekdayText) at \(timeText)"
                } else {
                    return "Every \(weekdayText)"
                }
            }
        }

        return "Repeating reminder"
    }

    func weekdayName(_ weekday: Int?) -> String? {
        guard let weekday else { return nil }
        let names = [
            1: "Sunday",
            2: "Monday",
            3: "Tuesday",
            4: "Wednesday",
            5: "Thursday",
            6: "Friday",
            7: "Saturday"
        ]
        return names[weekday]
    }

    func formattedTime(hour: Int?, minute: Int?) -> String? {
        guard let hour, let minute else { return nil }

        var components = DateComponents()
        components.hour = hour
        components.minute = minute

        let formatter = DateFormatter()
        formatter.timeStyle = .short

        if let date = Calendar.current.date(from: components) {
            return formatter.string(from: date)
        }
        return nil
    }
}

#Preview {
    NavigationStack {
        RemindersView()
            .environmentObject(ReminderStore())
    }
}
