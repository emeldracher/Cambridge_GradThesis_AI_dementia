import Foundation
import AVFoundation

@MainActor
final class SpeechOutputManager: NSObject, ObservableObject {
    static let shared = SpeechOutputManager()

    private var player: AVAudioPlayer?
    @Published var isSpeaking = false

    private override init() {
        super.init()
    }

    func stop() {
        player?.stop()
        player = nil
        isSpeaking = false
    }

    func speakFromBackend(_ text: String) async {
        let cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return }

        stop()

        do {
            guard let url = URL(string: "http://127.0.0.1:3000/tts") else {
                print("Invalid TTS URL")
                return
            }

            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")

            let body = ["text": cleaned]
            request.httpBody = try JSONEncoder().encode(body)

            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                print("Bad TTS server response")
                return
            }

            guard (200...299).contains(httpResponse.statusCode) else {
                let serverText = String(data: data, encoding: .utf8) ?? "Unknown TTS error"
                print("TTS server returned:", serverText)
                return
            }

            let ttsResponse = try JSONDecoder().decode(TTSResponse.self, from: data)

            guard let audioData = Data(base64Encoded: ttsResponse.audio_base64) else {
                print("Failed to decode base64 audio.")
                return
            }

            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.duckOthers])
            try AVAudioSession.sharedInstance().setActive(true)

            player = try AVAudioPlayer(data: audioData)
            player?.delegate = self
            player?.prepareToPlay()
            player?.play()
            isSpeaking = true
        } catch {
            print("Speech playback error:", error)
            isSpeaking = false
        }
    }
}

extension SpeechOutputManager: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        isSpeaking = false
    }
}
