//
//  GamesView.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import SwiftUI

struct GamesView: View {
    var body: some View {
        List {
            NavigationLink("Word Scramble") {
                WordScrambleView()
            }

            NavigationLink("Category Challenge") {
                CategoryChallengeView()
            }
        }
        .navigationTitle("Games")
    }
}

#Preview {
    NavigationStack {
        GamesView()
    }
}
