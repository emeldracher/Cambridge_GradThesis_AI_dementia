//
//  TTSResponse.swift
//  CooperCareios
//
//  Created by Emelie Eldracher on 4/21/26.
//

import Foundation

struct TTSResponse: Decodable {
    let audio_base64: String
    let mime_type: String
}
