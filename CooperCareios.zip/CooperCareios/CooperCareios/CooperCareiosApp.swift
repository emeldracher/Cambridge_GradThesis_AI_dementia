import SwiftUI

@main
struct CooperCareiosApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var reminderStore = ReminderStore()
    @StateObject private var memoryStore = ConversationMemoryStore()

    init() {
        Task {
            await NotificationManager.shared.requestPermission()
        }
    }

    var body: some Scene {
        WindowGroup {
            AppTabView()
                .environmentObject(reminderStore)
                .environmentObject(memoryStore)
        }
    }
}
