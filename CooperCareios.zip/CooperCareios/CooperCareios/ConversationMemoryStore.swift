import Foundation

struct ConversationTurn: Identifiable, Codable, Equatable {
    let id: UUID
    let role: String
    let content: String
    let timestamp: Date

    init(id: UUID = UUID(), role: String, content: String, timestamp: Date = Date()) {
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
    }
}

struct MemoryFact: Identifiable, Codable, Equatable {
    let id: UUID
    var key: String
    var value: String
    var category: String
    var source: String
    var notes: String?

    init(
        id: UUID = UUID(),
        key: String,
        value: String,
        category: String,
        source: String,
        notes: String? = nil
    ) {
        self.id = id
        self.key = key
        self.value = value
        self.category = category
        self.source = source
        self.notes = notes
    }
}

@MainActor
final class ConversationMemoryStore: ObservableObject {
    @Published var recentMessages: [ConversationTurn] = []
    @Published var profileFacts: [MemoryFact] = []
    @Published var summary: String = ""
    @Published var repeatTopicCounts: [String: Int] = [:]

    private let recentMessagesKey = "coopercare_recent_messages"
    private let profileFactsKey = "coopercare_profile_facts"
    private let summaryKey = "coopercare_summary"
    private let repeatTopicCountsKey = "coopercare_repeat_topic_counts"

    init() {
        load()
    }

    func addMessage(role: String, content: String) {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        recentMessages.append(
            ConversationTurn(role: role, content: trimmed)
        )

        if recentMessages.count > 20 {
            recentMessages = Array(recentMessages.suffix(20))
        }

        save()
    }

    func updateSummary(_ newSummary: String?) {
        guard let newSummary else { return }
        let trimmed = newSummary.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        summary = trimmed
        save()
    }

    func applyMemoryUpdates(_ updates: [MemoryUpdate]) {
        for update in updates {
            let trimmedKey = update.key.trimmingCharacters(in: .whitespacesAndNewlines)
            let trimmedValue = update.value.trimmingCharacters(in: .whitespacesAndNewlines)
            let trimmedCategory = update.category.trimmingCharacters(in: .whitespacesAndNewlines)
            let trimmedNotes = update.notes?.trimmingCharacters(in: .whitespacesAndNewlines)

            guard !trimmedKey.isEmpty, !trimmedValue.isEmpty, !trimmedCategory.isEmpty else { continue }

            if let index = profileFacts.firstIndex(where: {
                $0.key.caseInsensitiveCompare(trimmedKey) == .orderedSame
            }) {
                if profileFacts[index].source != "caregiver" {
                    profileFacts[index] = MemoryFact(
                        id: profileFacts[index].id,
                        key: trimmedKey,
                        value: trimmedValue,
                        category: trimmedCategory,
                        source: "assistant",
                        notes: trimmedNotes
                    )
                }
            } else {
                profileFacts.append(
                    MemoryFact(
                        key: trimmedKey,
                        value: trimmedValue,
                        category: trimmedCategory,
                        source: "assistant",
                        notes: trimmedNotes
                    )
                )
            }
        }

        save()
    }

    func addOrUpdateFact(
        key: String,
        value: String,
        category: String,
        source: String,
        notes: String?
    ) {
        let trimmedKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedValue = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedCategory = category.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedSource = source.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedNotes = notes?.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedKey.isEmpty, !trimmedValue.isEmpty, !trimmedCategory.isEmpty, !trimmedSource.isEmpty else {
            return
        }

        if let index = profileFacts.firstIndex(where: {
            $0.key.caseInsensitiveCompare(trimmedKey) == .orderedSame
        }) {
            profileFacts[index].value = trimmedValue
            profileFacts[index].category = trimmedCategory
            profileFacts[index].source = trimmedSource
            profileFacts[index].notes = trimmedNotes
        } else {
            profileFacts.append(
                MemoryFact(
                    key: trimmedKey,
                    value: trimmedValue,
                    category: trimmedCategory,
                    source: trimmedSource,
                    notes: trimmedNotes
                )
            )
        }

        save()
    }

    func deleteFact(at offsets: IndexSet) {
        profileFacts.remove(atOffsets: offsets)
        save()
    }

    func incrementRepeatCount(for topic: String?) {
        guard let topic else { return }
        let normalized = topic.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !normalized.isEmpty else { return }
        repeatTopicCounts[normalized, default: 0] += 1
        save()
    }

    func repeatCount(for topic: String?) -> Int {
        guard let topic else { return 0 }
        let normalized = topic.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !normalized.isEmpty else { return 0 }
        return repeatTopicCounts[normalized, default: 0]
    }

    func inferredRepeatCount(for message: String) -> Int {
        let normalizedCurrent = normalize(message)
        guard !normalizedCurrent.isEmpty else { return 0 }

        let recentUserMessages = recentMessages
            .filter { $0.role == "user" }
            .suffix(6)
            .map { normalize($0.content) }

        let matches = recentUserMessages.filter { $0 == normalizedCurrent }.count
        return matches
    }

    func clearConversationOnly() {
        recentMessages.removeAll()
        summary = ""
        repeatTopicCounts.removeAll()
        save()
    }

    func clearAll() {
        recentMessages.removeAll()
        profileFacts.removeAll()
        summary = ""
        repeatTopicCounts.removeAll()
        save()
    }

    private func normalize(_ text: String) -> String {
        let lowered = text.lowercased()
        let allowed = lowered.map { char -> Character in
            if char.isLetter || char.isNumber || char.isWhitespace {
                return char
            } else {
                return " "
            }
        }
        return String(allowed)
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func save() {
        do {
            let recentData = try JSONEncoder().encode(recentMessages)
            UserDefaults.standard.set(recentData, forKey: recentMessagesKey)

            let factsData = try JSONEncoder().encode(profileFacts)
            UserDefaults.standard.set(factsData, forKey: profileFactsKey)

            UserDefaults.standard.set(summary, forKey: summaryKey)

            let repeatData = try JSONEncoder().encode(repeatTopicCounts)
            UserDefaults.standard.set(repeatData, forKey: repeatTopicCountsKey)
        } catch {
            print("Failed to save memory store:", error)
        }
    }

    private func load() {
        do {
            if let recentData = UserDefaults.standard.data(forKey: recentMessagesKey) {
                recentMessages = try JSONDecoder().decode([ConversationTurn].self, from: recentData)
            }

            if let factsData = UserDefaults.standard.data(forKey: profileFactsKey) {
                profileFacts = try JSONDecoder().decode([MemoryFact].self, from: factsData)
            }

            summary = UserDefaults.standard.string(forKey: summaryKey) ?? ""

            if let repeatData = UserDefaults.standard.data(forKey: repeatTopicCountsKey) {
                repeatTopicCounts = try JSONDecoder().decode([String: Int].self, from: repeatData)
            }
        } catch {
            print("Failed to load memory store:", error)
        }
    }
}
